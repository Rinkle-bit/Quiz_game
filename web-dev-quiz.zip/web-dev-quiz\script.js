const questions = [
  {
    category: "html",
    difficulty: "beginner",
    question: "Which HTML element should wrap the main unique content of a page?",
    answers: ["<section>", "<main>", "<article>", "<body>"],
    correct: 1,
    hint: "There should usually be only one of this landmark on a page.",
    explanation: "<main> identifies the primary content and improves navigation for assistive technology."
  },
  {
    category: "html",
    difficulty: "beginner",
    question: "What does the alt attribute on an image provide?",
    answers: ["A tooltip only", "Alternative text", "Image compression", "Lazy loading"],
    correct: 1,
    hint: "Screen readers can announce it when the image cannot be perceived visually.",
    explanation: "Alt text describes the purpose or content of an image for accessibility and fallback display."
  },
  {
    category: "html",
    difficulty: "intermediate",
    question: "Which input type gives browsers a built-in email-specific keyboard and validation?",
    answers: ["type=\"text\"", "type=\"mail\"", "type=\"email\"", "type=\"address\""],
    correct: 2,
    hint: "It is named after the format it validates.",
    explanation: "type=\"email\" enables email-aware validation and better mobile keyboards."
  },
  {
    category: "css",
    difficulty: "beginner",
    question: "Which CSS property changes the space inside an element's border?",
    answers: ["margin", "padding", "gap", "outline"],
    correct: 1,
    hint: "Margin lives outside the border; this one lives inside it.",
    explanation: "Padding adds inner spacing between content and the element border."
  },
  {
    category: "css",
    difficulty: "intermediate",
    question: "In Flexbox, which property controls the main axis alignment?",
    answers: ["align-items", "justify-content", "place-self", "grid-auto-flow"],
    correct: 1,
    hint: "It often moves items left, right, center, or spaced out in a row.",
    explanation: "justify-content distributes flex items along the main axis."
  },
  {
    category: "css",
    difficulty: "advanced",
    question: "What does minmax(240px, 1fr) mean in a CSS Grid track?",
    answers: ["Always 240px", "At least 240px, then share available space", "Between 1px and 240px", "Exactly one fraction of 240px"],
    correct: 1,
    hint: "The first value is the lower bound.",
    explanation: "minmax(240px, 1fr) keeps a track at least 240px wide and lets it grow as a fraction."
  },
  {
    category: "javascript",
    difficulty: "beginner",
    question: "Which keyword declares a block-scoped variable that can be reassigned?",
    answers: ["const", "let", "var", "static"],
    correct: 1,
    hint: "It is commonly paired with const in modern JavaScript.",
    explanation: "let creates a block-scoped binding and allows reassignment."
  },
  {
    category: "javascript",
    difficulty: "intermediate",
    question: "What does event.preventDefault() do?",
    answers: ["Stops all JavaScript", "Cancels the browser's default action", "Deletes the event", "Reloads the page"],
    correct: 1,
    hint: "Think form submit or link navigation.",
    explanation: "preventDefault cancels a cancelable browser action while the event can still propagate."
  },
  {
    category: "javascript",
    difficulty: "advanced",
    question: "What is the result of Promise.all when one promise rejects?",
    answers: ["It ignores the rejected promise", "It resolves with null", "It rejects immediately", "It retries automatically"],
    correct: 2,
    hint: "One failure is enough to fail the whole group.",
    explanation: "Promise.all rejects as soon as any input promise rejects."
  },
  {
    category: "accessibility",
    difficulty: "beginner",
    question: "Which practice helps keyboard users understand where they are?",
    answers: ["Removing outlines", "Visible focus styles", "Tiny text", "Autoplay audio"],
    correct: 1,
    hint: "Tab through a page and watch for it.",
    explanation: "Visible focus styles show which interactive element currently has keyboard focus."
  },
  {
    category: "accessibility",
    difficulty: "intermediate",
    question: "What does aria-live help with?",
    answers: ["Announcing dynamic updates", "Styling animations", "Loading fonts", "Encrypting forms"],
    correct: 0,
    hint: "It is useful for status messages that appear without a page reload.",
    explanation: "aria-live regions let assistive technologies announce dynamic content changes."
  },
  {
    category: "accessibility",
    difficulty: "advanced",
    question: "When should you use role=\"button\" on a non-button element?",
    answers: ["Always for styling", "Only when a real button cannot be used and keyboard behavior is added", "To make links blue", "To improve SEO"],
    correct: 1,
    hint: "Native controls are usually better.",
    explanation: "A real button is preferred. If role=\"button\" is unavoidable, keyboard activation and focus handling must be provided."
  },
  {
    category: "performance",
    difficulty: "beginner",
    question: "Which image attribute can delay loading off-screen images?",
    answers: ["loading=\"lazy\"", "defer=\"image\"", "async=\"lazy\"", "fetch=\"later\""],
    correct: 0,
    hint: "It is a native loading hint.",
    explanation: "loading=\"lazy\" tells the browser it may defer off-screen image loading."
  },
  {
    category: "performance",
    difficulty: "intermediate",
    question: "Why should critical CSS be small?",
    answers: ["CSS cannot cache", "Large render-blocking CSS can delay first paint", "Small CSS disables layout", "Browsers dislike colors"],
    correct: 1,
    hint: "CSS is often needed before the browser can paint the page.",
    explanation: "Large render-blocking stylesheets can postpone rendering and harm perceived speed."
  },
  {
    category: "performance",
    difficulty: "advanced",
    question: "Which metric focuses on visual stability?",
    answers: ["TTFB", "CLS", "FID", "INP"],
    correct: 1,
    hint: "It measures unexpected layout movement.",
    explanation: "Cumulative Layout Shift measures unexpected visual movement during page life."
  },
  {
    category: "html",
    difficulty: "advanced",
    question: "Why use the defer attribute on a script tag?",
    answers: ["It blocks parsing", "It loads CSS first only", "It executes after parsing while preserving order", "It disables JavaScript errors"],
    correct: 2,
    hint: "Deferred scripts wait for the document to be parsed.",
    explanation: "defer downloads scripts during parsing and executes them after parsing, in document order."
  },
  {
    category: "css",
    difficulty: "intermediate",
    question: "Which selector targets a button only when hovered and enabled?",
    answers: ["button:hover:not(:disabled)", "button enabled:hover", "button::hover", "button:enabled:hovered"],
    correct: 0,
    hint: "It combines a pseudo-class with :not().",
    explanation: "button:hover:not(:disabled) matches hovered buttons that are not disabled."
  },
  {
    category: "javascript",
    difficulty: "intermediate",
    question: "Which method converts a JSON string into a JavaScript object?",
    answers: ["JSON.stringify()", "JSON.parse()", "Object.fromJSON()", "String.toObject()"],
    correct: 1,
    hint: "Stringify goes the other way.",
    explanation: "JSON.parse() reads a JSON string and returns the represented value."
  }
];

const state = {
  activeQuestions: [],
  currentIndex: 0,
  score: 0,
  streak: 0,
  bestStreak: 0,
  correct: 0,
  answered: 0,
  bonus: 0,
  selected: null,
  timerOn: true,
  timeLeft: 30,
  timer: null,
  review: [],
  locked: false,
  xp: Number(localStorage.getItem("webcraft-xp") || 0)
};

const els = {
  categorySelect: document.querySelector("#categorySelect"),
  difficultySelect: document.querySelector("#difficultySelect"),
  roundLength: document.querySelector("#roundLength"),
  roundLengthLabel: document.querySelector("#roundLengthLabel"),
  timerToggle: document.querySelector("#timerToggle"),
  startBtn: document.querySelector("#startBtn"),
  scoreValue: document.querySelector("#scoreValue"),
  streakValue: document.querySelector("#streakValue"),
  accuracyValue: document.querySelector("#accuracyValue"),
  timeValue: document.querySelector("#timeValue"),
  questionMeta: document.querySelector("#questionMeta"),
  questionText: document.querySelector("#questionText"),
  answerGrid: document.querySelector("#answerGrid"),
  hintBtn: document.querySelector("#hintBtn"),
  skipBtn: document.querySelector("#skipBtn"),
  nextBtn: document.querySelector("#nextBtn"),
  feedback: document.querySelector("#feedback"),
  progressCircle: document.querySelector("#progressCircle"),
  progressText: document.querySelector("#progressText"),
  goalCorrect: document.querySelector("#goalCorrect"),
  goalStreak: document.querySelector("#goalStreak"),
  goalBonus: document.querySelector("#goalBonus"),
  reviewList: document.querySelector("#reviewList"),
  exportBtn: document.querySelector("#exportBtn"),
  leaderboard: document.querySelector("#leaderboard"),
  resetScoresBtn: document.querySelector("#resetScoresBtn"),
  resultModal: document.querySelector("#resultModal"),
  closeModalBtn: document.querySelector("#closeModalBtn"),
  finalScore: document.querySelector("#finalScore"),
  resultTitle: document.querySelector("#resultTitle"),
  resultSummary: document.querySelector("#resultSummary"),
  playAgainBtn: document.querySelector("#playAgainBtn"),
  newSetupBtn: document.querySelector("#newSetupBtn"),
  xpText: document.querySelector("#xpText"),
  xpBar: document.querySelector("#xpBar"),
  rankLabel: document.querySelector("#rankLabel"),
  themeToggle: document.querySelector("#themeToggle"),
  themeIcon: document.querySelector("#themeIcon"),
  themeLabel: document.querySelector("#themeLabel")
};

function getInitialTheme() {
  const storedTheme = localStorage.getItem("webcraft-theme");
  if (storedTheme === "light" || storedTheme === "dark") return storedTheme;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function applyTheme(theme) {
  const isDark = theme === "dark";
  document.documentElement.dataset.theme = theme;
  localStorage.setItem("webcraft-theme", theme);
  els.themeToggle.setAttribute("aria-pressed", String(isDark));
  els.themeToggle.setAttribute("aria-label", `Switch to ${isDark ? "light" : "dark"} mode`);
  els.themeIcon.textContent = isDark ? "L" : "D";
  els.themeLabel.textContent = isDark ? "Light" : "Dark";
}

function toggleTheme() {
  const current = document.documentElement.dataset.theme || getInitialTheme();
  applyTheme(current === "dark" ? "light" : "dark");
}

function shuffle(items) {
  return [...items].sort(() => Math.random() - 0.5);
}

function formatTime(seconds) {
  return `00:${String(Math.max(seconds, 0)).padStart(2, "0")}`;
}

function getFilteredQuestions() {
  const category = els.categorySelect.value;
  const difficulty = els.difficultySelect.value;
  let filtered = questions.filter((item) => {
    const categoryMatch = category === "all" || item.category === category;
    const difficultyMatch = difficulty === "mixed" || item.difficulty === difficulty;
    return categoryMatch && difficultyMatch;
  });

  if (filtered.length < Number(els.roundLength.value)) {
    filtered = questions.filter((item) => category === "all" || item.category === category);
  }

  return shuffle(filtered).slice(0, Number(els.roundLength.value));
}

function startRound() {
  state.activeQuestions = getFilteredQuestions();
  state.currentIndex = 0;
  state.score = 0;
  state.streak = 0;
  state.bestStreak = 0;
  state.correct = 0;
  state.answered = 0;
  state.bonus = 0;
  state.selected = null;
  state.locked = false;
  state.review = [];
  state.timeLeft = 30;
  clearInterval(state.timer);
  els.resultModal.classList.remove("is-open");
  els.resultModal.setAttribute("aria-hidden", "true");
  els.exportBtn.disabled = true;
  renderQuestion();
  updateStats();
}

function renderQuestion() {
  const question = state.activeQuestions[state.currentIndex];
  if (!question) {
    finishRound();
    return;
  }

  state.selected = null;
  state.locked = false;
  state.timeLeft = 30;
  els.questionMeta.textContent = `${question.category.toUpperCase()} • ${question.difficulty} • Question ${state.currentIndex + 1}`;
  els.questionText.textContent = question.question;
  els.answerGrid.innerHTML = "";
  els.feedback.className = "feedback";
  els.feedback.textContent = "Choose an answer. Keys 1-4 work too.";
  els.hintBtn.disabled = false;
  els.skipBtn.disabled = false;
  els.nextBtn.disabled = true;

  question.answers.forEach((answer, index) => {
    const button = document.createElement("button");
    button.className = "answer-btn";
    button.type = "button";
    button.textContent = `${index + 1}. ${answer}`;
    button.addEventListener("click", () => selectAnswer(index));
    els.answerGrid.appendChild(button);
  });

  updateProgress();
  startTimer();
}

function startTimer() {
  clearInterval(state.timer);
  els.timeValue.textContent = state.timerOn ? formatTime(state.timeLeft) : "∞";
  if (!state.timerOn) return;

  state.timer = setInterval(() => {
    state.timeLeft -= 1;
    els.timeValue.textContent = formatTime(state.timeLeft);
    if (state.timeLeft <= 0) {
      clearInterval(state.timer);
      lockQuestion(null, true);
    }
  }, 1000);
}

function selectAnswer(index) {
  if (state.locked || !state.activeQuestions[state.currentIndex]) return;
  lockQuestion(index, false);
}

function lockQuestion(index, timedOut) {
  const question = state.activeQuestions[state.currentIndex];
  if (!question || state.locked) return;
  const buttons = [...document.querySelectorAll(".answer-btn")];
  const isCorrect = index === question.correct;
  state.selected = index;
  state.locked = true;
  state.answered += 1;
  clearInterval(state.timer);

  buttons.forEach((button, buttonIndex) => {
    button.disabled = true;
    if (buttonIndex === question.correct) button.classList.add("correct");
    if (buttonIndex === index && !isCorrect) button.classList.add("wrong");
  });

  if (isCorrect) {
    const timeBonus = state.timerOn ? Math.max(state.timeLeft, 0) : 6;
    const streakBonus = state.streak >= 2 ? 10 : 0;
    const points = 50 + timeBonus + streakBonus;
    state.score += points;
    state.correct += 1;
    state.streak += 1;
    state.bestStreak = Math.max(state.bestStreak, state.streak);
    state.bonus += timeBonus + streakBonus;
    els.feedback.className = "feedback good";
    els.feedback.textContent = `Correct. +${points} points. ${question.explanation}`;
  } else {
    state.streak = 0;
    els.feedback.className = "feedback bad";
    els.feedback.textContent = timedOut
      ? `Time ran out. ${question.explanation}`
      : `Not quite. ${question.explanation}`;
  }

  state.review.push({
    question: question.question,
    correct: isCorrect,
    answer: index === null ? "No answer" : question.answers[index],
    rightAnswer: question.answers[question.correct]
  });

  els.hintBtn.disabled = true;
  els.skipBtn.disabled = true;
  els.nextBtn.disabled = false;
  els.exportBtn.disabled = false;
  updateStats();
  renderReview();
}

function nextQuestion() {
  state.currentIndex += 1;
  if (state.currentIndex >= state.activeQuestions.length) {
    finishRound();
  } else {
    renderQuestion();
  }
}

function skipQuestion() {
  if (state.locked) return;
  lockQuestion(null, false);
}

function showHint() {
  const question = state.activeQuestions[state.currentIndex];
  if (!question) return;
  els.feedback.className = "feedback";
  els.feedback.textContent = `Hint: ${question.hint}`;
  els.hintBtn.disabled = true;
  state.score = Math.max(0, state.score - 5);
  updateStats();
}

function updateStats() {
  const accuracy = state.answered ? Math.round((state.correct / state.answered) * 100) : 0;
  els.scoreValue.textContent = state.score;
  els.streakValue.textContent = state.streak;
  els.accuracyValue.textContent = `${accuracy}%`;
  els.goalCorrect.textContent = state.correct;
  els.goalStreak.textContent = state.bestStreak;
  els.goalBonus.textContent = state.bonus;
  updateXp();
}

function updateProgress() {
  const total = state.activeQuestions.length || 0;
  const current = total ? Math.min(state.currentIndex + 1, total) : 0;
  const percent = total ? Math.min(state.currentIndex, total) / total : 0;
  const circumference = 119.38;
  els.progressText.textContent = `${current}/${total}`;
  els.progressCircle.style.strokeDashoffset = String(circumference - circumference * percent);
}

function renderReview() {
  if (!state.review.length) {
    els.reviewList.innerHTML = '<p class="muted">Your answers will appear here after the round begins.</p>';
    return;
  }

  els.reviewList.innerHTML = state.review.map((item, index) => `
    <div class="review-item ${item.correct ? "correct" : "wrong"}">
      <strong>${index + 1}. ${item.question}</strong>
      <small>Your answer: ${item.answer} • Correct: ${item.rightAnswer}</small>
    </div>
  `).join("");
}

function finishRound() {
  clearInterval(state.timer);
  const earnedXp = state.score + state.correct * 15 + state.bestStreak * 20;
  state.xp += earnedXp;
  localStorage.setItem("webcraft-xp", String(state.xp));
  saveScore();
  renderLeaderboard();
  updateXp();

  const accuracy = state.answered ? Math.round((state.correct / state.answered) * 100) : 0;
  els.finalScore.textContent = state.score;
  els.resultTitle.textContent = accuracy >= 80 ? "Frontend wizardry" : accuracy >= 50 ? "Solid progress" : "Keep building";
  els.resultSummary.textContent = `${state.correct}/${state.activeQuestions.length} correct, ${accuracy}% accuracy, best streak ${state.bestStreak}. You earned ${earnedXp} XP.`;
  els.resultModal.classList.add("is-open");
  els.resultModal.setAttribute("aria-hidden", "false");
  els.nextBtn.disabled = true;
  els.hintBtn.disabled = true;
  els.skipBtn.disabled = true;
  updateProgress();
}

function saveScore() {
  const scores = JSON.parse(localStorage.getItem("webcraft-scores") || "[]");
  scores.push({
    score: state.score,
    correct: state.correct,
    total: state.activeQuestions.length,
    date: new Date().toLocaleDateString()
  });
  localStorage.setItem("webcraft-scores", JSON.stringify(scores.sort((a, b) => b.score - a.score).slice(0, 5)));
}

function renderLeaderboard() {
  const scores = JSON.parse(localStorage.getItem("webcraft-scores") || "[]");
  if (!scores.length) {
    els.leaderboard.innerHTML = "<li>No scores yet</li>";
    return;
  }

  els.leaderboard.innerHTML = scores.map((score) => (
    `<li><strong>${score.score}</strong> pts · ${score.correct}/${score.total} · ${score.date}</li>`
  )).join("");
}

function updateXp() {
  const ranks = [
    { name: "Apprentice", min: 0 },
    { name: "Component Crafter", min: 600 },
    { name: "Layout Specialist", min: 1500 },
    { name: "Full Stack Adept", min: 3000 },
    { name: "Web Architect", min: 5200 }
  ];
  const current = ranks.reduce((rank, candidate) => state.xp >= candidate.min ? candidate : rank, ranks[0]);
  const next = ranks.find((rank) => rank.min > state.xp);
  const progress = next ? ((state.xp - current.min) / (next.min - current.min)) * 100 : 100;
  els.rankLabel.textContent = current.name;
  els.xpText.textContent = `${state.xp} XP`;
  els.xpBar.style.width = `${Math.max(0, Math.min(progress, 100))}%`;
}

function exportReview() {
  const lines = state.review.map((item, index) => {
    return `${index + 1}. ${item.question}\nYour answer: ${item.answer}\nCorrect answer: ${item.rightAnswer}\nResult: ${item.correct ? "Correct" : "Wrong"}`;
  });
  const blob = new Blob([lines.join("\n\n")], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "webcraft-quiz-review.txt";
  link.click();
  URL.revokeObjectURL(url);
}

els.roundLength.addEventListener("input", () => {
  els.roundLengthLabel.textContent = els.roundLength.value;
});

els.timerToggle.addEventListener("click", () => {
  state.timerOn = !state.timerOn;
  els.timerToggle.classList.toggle("is-on", state.timerOn);
  els.timerToggle.setAttribute("aria-pressed", String(state.timerOn));
});

els.themeToggle.addEventListener("click", toggleTheme);
els.startBtn.addEventListener("click", startRound);
els.nextBtn.addEventListener("click", nextQuestion);
els.skipBtn.addEventListener("click", skipQuestion);
els.hintBtn.addEventListener("click", showHint);
els.exportBtn.addEventListener("click", exportReview);
els.resetScoresBtn.addEventListener("click", () => {
  localStorage.removeItem("webcraft-scores");
  renderLeaderboard();
});
function closeModal() {
  els.resultModal.classList.remove("is-open");
  els.resultModal.setAttribute("aria-hidden", "true");
}

els.closeModalBtn.addEventListener("click", closeModal);
els.playAgainBtn.addEventListener("click", startRound);
els.newSetupBtn.addEventListener("click", closeModal);

document.addEventListener("keydown", (event) => {
  if (event.key >= "1" && event.key <= "4") {
    selectAnswer(Number(event.key) - 1);
  }
  if (event.key === "Enter" && !els.nextBtn.disabled) {
    nextQuestion();
  }
});

renderLeaderboard();
renderReview();
applyTheme(getInitialTheme());
updateStats();
